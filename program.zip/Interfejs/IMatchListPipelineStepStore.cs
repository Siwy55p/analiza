namespace STSAnaliza.Interfejs
{
    // marker-interface aby mieć 2 różne store’y w DI
    public interface IMatchListPipelineStepStore : IPipelineStepStore
    {
    }
}
